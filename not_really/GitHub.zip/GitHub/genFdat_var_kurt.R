#Gina-Maria Pomann
#9/8/2012
#Functional Data Generation Code for Skewness Shifts
#######################################################################
#This code will generate a set of functional data to be used for 
#simulation studies for our solution to the two sample problem. 
#It will generate the data such using the karhunen Loeve expansion of a 
#functional data set. Meaning we will use the mean function, basis functions, 
#and scores (generated randomly) to generate the set of curves. 

# n (integer): 
#   The number of samples in the functional data set

# m (integer): 
#   The number of obeservations along each curve ranging from 0 to 1

# s2e (integer): 
#   The error variance for the measurement error which is 
#   independently distributed among the curves

# lv (vector): 
#   The 'lambda vector' which consists of the variances of each of the 
#   score distributions. The number of eigenfunctions will be taken to be 
#   the length of this vector

#mf (vector-of length n): 
#   The mean function for the data set. This will default to zero if it 
#   not input to the function.

#basis (character): 
#   This indicates the type of basis function and can take values, 
#   'F',for forier and 'P' for polynomial.

#nu (integer): 
#   The degrees of freedom used to generate the score distributions

#df.mask (vector of characters- length of lv): 
#   This specifies the value of the skewness parameter of the generating distribution 
#   for each of the scores. 
#   NA represents no skewness so that the data is simply generated from a standard T 
#   distribution with df nu

######################################################################

require(fGarch)
require(fda)

#s2e<-sigma2_eps.1
#lv<-sig2vec.1

genFdat_var_kurt<-function(n,m,s2e,lv,mf,basis.type,dfmask,nu){
  
  #take the number of basis functions to equal the length of 
  #the vector of score variances. 
  K.fda<-length(lv)
  
  #ensure that the variance and skewness vectors are of the same length
  if(K.fda!=length(dfmask)){print('lv and dfmask not of equal length')}
  
  #declare functions that are used to generate basis 
  if(basis.type=='F'){
    ## We use Discrete Fourier Transformation (DFT) basis system  on [0,1] (phis)
    theta1 = function(t){sqrt(2)* sin(2*pi*t)}
    theta2 = function(t){sqrt(2)* cos(2*pi*t)}
    theta3 = function(t){sqrt(2)* sin(4*pi*t)}
    theta4 = function(t){sqrt(2)* cos(4*pi*t)}
    theta5 = function(t){sqrt(2)* sin(6*pi*t)}
  }
  
  #declare the set of points for the basis functions to be evaluated at
  tij.seq = seq((1/m),1, by= 1/m)
  
  
  
  #create a matrix out of the score variances
  Lambdasqrt.mat = diag(sqrt(lv))
  Lambda.mat = diag(lv)
  
  ##########################################################################
  #create the basis functions
  ##########################################################################
  
  
  #gerenate the basis functions and evaluate them at the grid points
  if(basis.type=='F'){
    #basis<-eval.basis(create.fourier.basis(nbasis=K.fda+3),tij.seq)
    #create the matrix of basis functions (m by k.fda)
    
    if(K.fda==1){
      basis=theta1(t=tij.seq) 
    }
    if(K.fda==2){
      basis=cbind(theta1(t=tij.seq) , theta2(t=tij.seq))}
    if(K.fda==3){
      basis=cbind(theta1(t=tij.seq) , theta2(t=tij.seq), theta3(t=tij.seq))}
    if(K.fda==4){
      basis=cbind(theta1(t=tij.seq) , theta2(t=tij.seq), theta3(t=tij.seq),theta4(t=tij.seq))
    }
    if(K.fda==5){
      basis=cbind(theta1(t=tij.seq) , theta2(t=tij.seq), theta3(t=tij.seq),theta4(t=tij.seq),theta5(t=tij.seq))
    }
    
  }
  
  if(basis.type=='P'){
    #basis<-eval.basis(create.polynomial.basis(nbasis=K.fda+3),tij.seq)
    print('this has not been coded yet')
  }
  
  ##########################################################################
  #create the score vectors by generating from the appropriate distributions 
  ##########################################################################
  #all scores are generated to have mean zero and the same variance
  xi.mat<-matrix(NA,K.fda,n)
  for(k in 1:K.fda){
    if(is.na(dfmask[k])==1){
      #print(k)
      xi.mat[k,]<-sqrt(lv[k])*rnorm(n,0)
    }
    if(is.na(dfmask[k])==0){
      df<-dfmask[k]
      xi.mat[k,]<-rt(n,df)
      #now make them have the same variance
      xi.mat[k,]<-sqrt(lv[k]*((df-2)/df))*xi.mat[k,]
      
    }#end if
  }#end for
  
  ##########################################################################
  #create random noise matrix to be added to the smooth functions 
  ########################################################################## 
  
  noise.mat = sqrt(s2e) * matrix(rnorm(m*n, mean=0, sd=1), nrow=m)
  
  ##########################################################################
  #create the random functions to be output 
  #data is an mxn matrix
  #mf is a vector so we create a matrix of size mxn that can be added to
  #basis %*% xi.mat + noise.mat
  ##########################################################################
  DATA = matrix(mf,length(mf),n) + basis %*% xi.mat + noise.mat
  
  list(DATA=DATA,basis=basis,xi.mat=xi.mat)
}#end function
